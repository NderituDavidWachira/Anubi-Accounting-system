

<?php $__env->startSection('title', 'General Ledger Statement'); ?>
<?php $__env->startSection('report-title', $account ? 'Account Statement: ' . $account->code . ' - ' . $account->name : 'General Ledger Statement'); ?>
<?php $__env->startSection('report-period', 'Period: ' . \Carbon\Carbon::parse($fromDate)->format('d M Y') . ' to ' . \Carbon\Carbon::parse($toDate)->format('d M Y')); ?>

<?php $__env->startSection('content'); ?>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Voucher #</th>
                <th>Account</th>
                <th>Narration / Memo</th>
                <th class="text-right">Debit (KSh)</th>
                <th class="text-right">Credit (KSh)</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                $totDebit = 0; 
                $totCredit = 0; 
            ?>
            
            <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php 
                    $totDebit += $entry->debit; 
                    $totCredit += $entry->credit; 
                    
                    // Fallback check for voucher date column depending on your table schema
                    $voucherDate = $entry->voucher->date ?? ($entry->voucher->created_at ?? now());
                ?>
                <tr>
                    <td><?php echo e(\Carbon\Carbon::parse($voucherDate)->format('d/m/Y')); ?></td>
                    <td><?php echo e($entry->voucher->voucher_number ?? '-'); ?></td>
                    <td><?php echo e($entry->account->name ?? '-'); ?></td>
                    <td><?php echo e($entry->voucher->narration ?? '-'); ?></td>
                    <td class="text-right"><?php echo e($entry->debit > 0 ? number_format($entry->debit, 2) : '-'); ?></td>
                    <td class="text-right"><?php echo e($entry->credit > 0 ? number_format($entry->credit, 2) : '-'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" style="text-align: center; color: #64748b; padding: 20px;">
                        No ledger transactions found for this date range.
                    </td>
                </tr>
            <?php endif; ?>

            <?php if($entries->count() > 0): ?>
                <tr class="total-row">
                    <td colspan="4">TOTAL MOVEMENT</td>
                    <td class="text-right">KSh <?php echo e(number_format($totDebit, 2)); ?></td>
                    <td class="text-right">KSh <?php echo e(number_format($totCredit, 2)); ?></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('reports.print-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Anubi Accounting system\resources\views/reports/print-general-ledger.blade.php ENDPATH**/ ?>