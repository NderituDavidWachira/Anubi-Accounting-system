

<?php $__env->startSection('title', 'Balance Sheet'); ?>
<?php $__env->startSection('report-title', 'Balance Sheet'); ?>
<?php $__env->startSection('report-period', 'As of: ' . \Carbon\Carbon::parse($toDate)->format('d M Y')); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $assets = [];
        $liabilities = [];
        $equity = [];
        $totAssets = 0;
        $totLiab = 0;
        $totEq = 0;
        $rev = 0;
        $exp = 0;

        foreach ($accounts as $acc) {
            $d = $acc->ledgerEntries->sum('debit');
            $c = $acc->ledgerEntries->sum('credit');
            $t = strtolower($acc->type);

            if ($t === 'asset' && ($d - $c) != 0) {
                $bal = $d - $c;
                $assets[] = ['code' => $acc->code, 'name' => $acc->name, 'bal' => $bal];
                $totAssets += $bal;
            } elseif ($t === 'liability' && ($c - $d) != 0) {
                $bal = $c - $d;
                $liabilities[] = ['code' => $acc->code, 'name' => $acc->name, 'bal' => $bal];
                $totLiab += $bal;
            } elseif ($t === 'equity' && ($c - $d) != 0) {
                $bal = $c - $d;
                $equity[] = ['code' => $acc->code, 'name' => $acc->name, 'bal' => $bal];
                $totEq += $bal;
            } elseif (in_array($t, ['revenue', 'income'])) {
                $rev += ($c - $d);
            } elseif (in_array($t, ['expense', 'expenses'])) {
                $exp += ($d - $c);
            }
        }
        $netEarnings = $rev - $exp;
    ?>

    <table>
        <thead>
            <tr>
                <th>Code</th>
                <th>Assets</th>
                <th class="text-right">Balance (KSh)</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item['code']); ?></td>
                    <td><?php echo e($item['name']); ?></td>
                    <td class="text-right"><?php echo e(number_format($item['bal'], 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr class="total-row">
                <td colspan="2">TOTAL ASSETS</td>
                <td class="text-right">KSh <?php echo e(number_format($totAssets, 2)); ?></td>
            </tr>
        </tbody>
    </table>

    <table>
        <thead>
            <tr>
                <th>Code</th>
                <th>Liabilities &amp; Equity</th>
                <th class="text-right">Balance (KSh)</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $liabilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item['code']); ?></td>
                    <td><?php echo e($item['name']); ?> (Liability)</td>
                    <td class="text-right"><?php echo e(number_format($item['bal'], 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $equity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item['code']); ?></td>
                    <td><?php echo e($item['name']); ?> (Equity)</td>
                    <td class="text-right"><?php echo e(number_format($item['bal'], 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>-</td>
                <td>Current Period Net Earnings / (Loss)</td>
                <td class="text-right"><?php echo e(number_format($netEarnings, 2)); ?></td>
            </tr>
            <tr class="total-row">
                <td colspan="2">TOTAL LIABILITIES &amp; EQUITY</td>
                <td class="text-right">KSh <?php echo e(number_format($totLiab + $totEq + $netEarnings, 2)); ?></td>
            </tr>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('reports.print-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Anubi Accounting system\resources\views/reports/print-balance-sheet.blade.php ENDPATH**/ ?>