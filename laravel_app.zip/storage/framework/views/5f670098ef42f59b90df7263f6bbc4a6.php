

<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-lg shadow-sm border p-6">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-2xl font-bold text-gray-800">Financial Vouchers</h1>
            <p class="text-sm text-gray-500">Record payments, receipts, and internal transfers</p>
        </div>
        <a href="<?php echo e(route('vouchers.create')); ?>" class="bg-emerald-600 hover:bg-emerald-700 text-white font-medium px-4 py-2 rounded-lg text-sm shadow">
            + New Voucher
        </a>
    </div>

    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Voucher #</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Date</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Type</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Payee / Source</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Program</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Status</th>
                    <th class="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 text-sm">
                <?php $__empty_1 = true; $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-3 font-semibold text-indigo-600"><?php echo e($voucher->voucher_number); ?></td>
                        <td class="px-4 py-3"><?php echo e($voucher->transaction_date->format('Y-m-d')); ?></td>
                        <td class="px-4 py-3 uppercase text-xs font-bold text-gray-600"><?php echo e($voucher->type); ?></td>
                        <td class="px-4 py-3"><?php echo e($voucher->payee_or_source); ?></td>
                        <td class="px-4 py-3"><?php echo e($voucher->program->name ?? 'N/A'); ?></td>
                        <td class="px-4 py-3">
                            <?php if($voucher->status === 'approved'): ?>
                                <span class="px-2 py-1 text-xs rounded bg-emerald-100 text-emerald-800 font-medium">Approved</span>
                            <?php else: ?>
                                <span class="px-2 py-1 text-xs rounded bg-amber-100 text-amber-800 font-medium">Pending</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3 text-right">
                            <a href="<?php echo e(route('vouchers.show', $voucher)); ?>" class="text-blue-600 hover:underline">View</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="px-4 py-6 text-center text-gray-400">No vouchers recorded yet.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($vouchers->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Anubi Accounting system\resources\views/vouchers/index.blade.php ENDPATH**/ ?>