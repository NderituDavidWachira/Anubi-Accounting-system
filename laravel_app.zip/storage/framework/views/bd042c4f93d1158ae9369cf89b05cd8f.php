

<?php $__env->startSection('title', 'Profit & Loss Statement'); ?>
<?php $__env->startSection('report-title', 'Profit & Loss Statement'); ?>
<?php $__env->startSection('report-period', 'Period: ' . \Carbon\Carbon::parse($fromDate)->format('d M Y') . ' to ' . \Carbon\Carbon::parse($toDate)->format('d M Y')); ?>

<?php $__env->startSection('content'); ?>
    <table>
        <thead>
            <tr>
                <th>Code</th>
                <th>Operating Revenue / Income Account</th>
                <th class="text-right">Amount (KSh)</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $revenues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($rev['code']); ?></td>
                    <td><?php echo e($rev['name']); ?></td>
                    <td class="text-right"><?php echo e(number_format($rev['amount'], 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" style="color: #64748b;">No operational revenue recorded in this period.</td>
                </tr>
            <?php endif; ?>
            <tr class="total-row">
                <td colspan="2">TOTAL OPERATING REVENUE</td>
                <td class="text-right">KSh <?php echo e(number_format($totalRevenue, 2)); ?></td>
            </tr>
        </tbody>
    </table>

    <table>
        <thead>
            <tr>
                <th>Code</th>
                <th>Operating Expense Account</th>
                <th class="text-right">Amount (KSh)</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($exp['code']); ?></td>
                    <td><?php echo e($exp['name']); ?></td>
                    <td class="text-right"><?php echo e(number_format($exp['amount'], 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" style="color: #64748b;">No operational expenses recorded in this period.</td>
                </tr>
            <?php endif; ?>
            <tr class="total-row">
                <td colspan="2">TOTAL OPERATING EXPENSES</td>
                <td class="text-right">KSh <?php echo e(number_format($totalExpenses, 2)); ?></td>
            </tr>
        </tbody>
    </table>

    <table>
        <tbody>
            <tr class="total-row" style="font-size: 15px;">
                <td>
                    NET OPERATING RESULT
                    <span style="font-size: 11px; font-weight: normal; color: #64748b;">(Excludes Opening Capital & Balance Sheet Assets)</span>
                </td>
                <td class="text-right <?php echo e($netProfitLoss < 0 ? 'loss' : 'profit'); ?>">
                    <?php echo e($netProfitLoss < 0 ? 'NET LOSS: KSh ' . number_format(abs($netProfitLoss), 2) : 'NET PROFIT: KSh ' . number_format($netProfitLoss, 2)); ?>

                </td>
            </tr>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('reports.print-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Anubi Accounting system\resources\views/reports/print-profit-loss.blade.php ENDPATH**/ ?>