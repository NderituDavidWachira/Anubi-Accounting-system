<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\LedgerEntry;
use App\Services\LedgerService;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    protected LedgerService $ledgerService;

    public function __construct(LedgerService $ledgerService)
    {
        $this->ledgerService = $ledgerService;
    }

    public function generalLedger(Request $request)
    {
        $accounts = Account::where('is_active', true)->orderBy('code')->get();
        $selectedAccountId = $request->input('account_id');
        $entries = collect();

        if ($selectedAccountId) {
            $entries = $this->ledgerService->getAccountLedger(
                (int) $selectedAccountId,
                $request->input('start_date'),
                $request->input('end_date')
            );
        }

        return view('reports.general-ledger', compact('accounts', 'selectedAccountId', 'entries'));
    }

    public function trialBalance(Request $request)
    {
        $asOfDate = $request->input('as_of_date', now()->format('Y-m-d'));
        
        // Pass $trialBalance to resolve Undefined variable $trialBalance in Blade
        $trialBalance = $this->ledgerService->generateTrialBalance($asOfDate);

        return view('reports.trial-balance', compact('trialBalance', 'asOfDate'));
    }

    public function balanceSheet(Request $request)
{
    $asOfDate = $request->input('as_of_date', now()->format('Y-m-d'));

    // 1. Fetch active accounts
    $accounts = Account::with(['children', 'parent'])
        ->where('is_active', true)
        ->orderBy('code')
        ->get();

    // 2. Identify strictly parent IDs (only accounts that have child accounts)
    $parentIds = Account::whereNotNull('parent_id')
        ->pluck('parent_id')
        ->unique()
        ->map(fn($id) => (int) $id)
        ->toArray();

    // 3. Compute net balance for each individual account from approved vouchers
    $balances = [];
    foreach ($accounts as $acc) {
        $totals = LedgerEntry::where('account_id', $acc->id)
            ->whereHas('voucher', function ($q) use ($asOfDate) {
                $q->where('status', 'approved')
                  ->where('transaction_date', '<=', $asOfDate);
            })
            ->selectRaw('COALESCE(SUM(debit), 0) as total_debit, COALESCE(SUM(credit), 0) as total_credit')
            ->first();

        $debit = (float) ($totals->total_debit ?? 0);
        $credit = (float) ($totals->total_credit ?? 0);

        if ($acc->type === 'asset') {
            $balances[$acc->id] = $debit - $credit;
        } elseif ($acc->type === 'expense') {
            $balances[$acc->id] = $debit - $credit;
        } else {
            $balances[$acc->id] = $credit - $debit;
        }
    }

    // 4. Roll up child sums strictly into parent headers
    foreach ($accounts as $acc) {
        if (in_array((int)$acc->id, $parentIds, true)) {
            $childSum = 0.0;
            foreach ($acc->children as $child) {
                $childSum += (float) ($balances[$child->id] ?? 0);
            }
            if (!isset($balances[$acc->id]) || $balances[$acc->id] == 0) {
                $balances[$acc->id] = $childSum;
            }
        }
    }

    $assets = $accounts->where('type', 'asset');
    $expenses = $accounts->where('type', 'expense');
    $liabilities = $accounts->where('type', 'liability');

    // 5. Total Assets: sum actual entries across all asset accounts
    $totalAssets = (float) LedgerEntry::whereHas('account', fn($q) => $q->where('type', 'asset')->where('is_active', true))
        ->whereHas('voucher', fn($q) => $q->where('status', 'approved')->where('transaction_date', '<=', $asOfDate))
        ->selectRaw('COALESCE(SUM(debit - credit), 0) as net')
        ->value('net');

    $totalExpenses = (float) LedgerEntry::whereHas('account', fn($q) => $q->where('type', 'expense')->where('is_active', true))
        ->whereHas('voucher', fn($q) => $q->where('status', 'approved')->where('transaction_date', '<=', $asOfDate))
        ->selectRaw('COALESCE(SUM(debit - credit), 0) as net')
        ->value('net');

    $totalLiabilities = (float) LedgerEntry::whereHas('account', fn($q) => $q->where('type', 'liability')->where('is_active', true))
        ->whereHas('voucher', fn($q) => $q->where('status', 'approved')->where('transaction_date', '<=', $asOfDate))
        ->selectRaw('COALESCE(SUM(credit - debit), 0) as net')
        ->value('net');

    // 6. Net Position
    $netAvailableBalance = $totalAssets - $totalExpenses;

    return view('reports.balance-sheet', compact(
        'asOfDate',
        'assets',
        'expenses',
        'liabilities',
        'balances',
        'parentIds',
        'totalAssets',
        'totalExpenses',
        'totalLiabilities',
        'netAvailableBalance'
    ));
}
}